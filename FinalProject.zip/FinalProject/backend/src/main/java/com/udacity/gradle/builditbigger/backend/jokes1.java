package com.udacity.gradle.builditbigger.backend;

public class jokes1 {
    private String text;

    public String getText() {
        return text;
    }

    public void setText(String text) {
        this.text = text;
    }


}
