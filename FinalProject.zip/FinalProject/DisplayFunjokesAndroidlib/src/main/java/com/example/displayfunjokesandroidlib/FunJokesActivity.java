package com.example.displayfunjokesandroidlib;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.TextView;

public class FunJokesActivity extends AppCompatActivity {

    String mJoke;
    String INTENT_JOKE_TEXT = "INTENT_JOKE_TEXT";
    String SAVE_INSTANCE_JOKE_TEXT = "SAVE_INSTANCE_JOKE_TEXT";
    TextView jokeshow;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_fun_jokes);
        jokeshow = findViewById(R.id.Jokes_show);

        if (savedInstanceState == null) {
            Intent intent = getIntent();
            mJoke = intent.getStringExtra(INTENT_JOKE_TEXT);
            SetJoke(mJoke);
        } else {
            mJoke = savedInstanceState.getString(SAVE_INSTANCE_JOKE_TEXT);
            SetJoke(mJoke);
        }





    }

    public void SetJoke(String mJoke)
    {
        jokeshow.setText(mJoke);
    }

    @Override
    protected void onSaveInstanceState(@NonNull Bundle currentState) {
        super.onSaveInstanceState(currentState);
        currentState.putString(SAVE_INSTANCE_JOKE_TEXT, mJoke);
    }
}