package com.example.thefunjokes

class FunJokes {
}