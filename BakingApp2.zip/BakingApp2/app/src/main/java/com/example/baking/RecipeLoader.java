package com.example.baking;

import android.content.Context;
import android.util.Log;

import androidx.loader.content.AsyncTaskLoader;

import java.util.List;

public class RecipeLoader extends AsyncTaskLoader<List<Recipe>> {

    private static final String LOG_TAG = RecipeLoader.class.getName();

    String url;

    public RecipeLoader(Context context, String url) {
        super(context);
        this.url = url;
    }

    @Override
    protected void onStartLoading() {
        forceLoad();
    }

    @Override
    public List<Recipe> loadInBackground() {

        Log.v(LOG_TAG,"RecipeLoader loadInBackground");

        if(url == null){
            return null;
        }

        List<Recipe> result = NetworkUtils.fetchRecipeData(url);

        return result;
    }
}
