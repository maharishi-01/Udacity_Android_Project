package Fragment;

import android.os.Bundle;

import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.udacity.gradle.band.R;

import java.util.ArrayList;
import java.util.List;

import Adapter.PriestAdapter;
import Model.PriestModel;
import ui_design.Main_Activity;

/**
 * A simple {@link Fragment} subclass.
 */
public class Priest extends Fragment {
    List<PriestModel> modelList;
    PriestAdapter pAdapter;
    RecyclerView recyclerView;

    public Priest() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {

        View view = inflater.inflate(R.layout.fragment_priest, container, false);
        recyclerView = view.findViewById(R.id.priest_recycler);
        modelList = new ArrayList<>();
        recyclerView.setLayoutManager(new LinearLayoutManager(view.getContext()));
        modelList.add(new PriestModel(R.drawable.account, "Pandit Rishi Raj Maharaj", "45",
                "Banka District Bakhtiyarpur", "900 per day", "987609876",
                "12 year"));
        modelList.add(new PriestModel(R.drawable.account, "Pandit Rishi Raj Maharaj", "45",
                "Banka District Bakhtiyarpur", "900 per day", "987609876",
                "12 year"));
        modelList.add(new PriestModel(R.drawable.account, "Pandit Rishi Raj Maharaj", "45",
                "Banka District Bakhtiyarpur", "900 per day", "987609876",
                "12 year"));
        modelList.add(new PriestModel(R.drawable.account, "Pandit Rishi Raj Maharaj", "45",
                "Banka District Bakhtiyarpur", "900 per day", "987609876",
                "12 year"));
        pAdapter = new PriestAdapter(modelList, view.getContext());
        recyclerView.setAdapter(pAdapter);
        pAdapter.notifyDataSetChanged();
        recyclerView.addOnScrollListener(new RecyclerView.OnScrollListener() {
            @Override
            public void onScrolled(RecyclerView recyclerView, int dx, int dy) {
                super.onScrolled(recyclerView, dx, dy);
                if (dy > 0) {
                    ((Main_Activity) requireActivity()).SetNavigationVisibility(false);
                } else if (dy < 0) {
                    ((Main_Activity) requireActivity()).SetNavigationVisibility(true);
                }
            }
        });
        return view;
    }
}
