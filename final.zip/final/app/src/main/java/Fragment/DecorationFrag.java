package Fragment;

import android.graphics.drawable.Drawable;
import android.os.AsyncTask;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.DividerItemDecoration;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.udacity.gradle.band.R;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Objects;

import Adapter.DecoAdapter;
import Model.DecoModel;
import Styling.RecyclerDividerItem;
import ui_design.Main_Activity;

/**
 * A simple {@link Fragment} subclass.
 */
public class DecorationFrag extends Fragment {
    List<DecoModel> modelList;
    DecoAdapter dAdapter;
    RecyclerView recyclerView;
    RecyclerView.ItemDecoration dividerItem;
    BottomNavigationView btmNav;
    DatabaseReference databaseReference;

    public DecorationFrag() {
        // Required empty public constructor
    }

    @Override
    public View onCreateView(final LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_decoration, container, false);
        recyclerView = view.findViewById(R.id.rec_deco);
        Drawable drawable = getResources().getDrawable(R.drawable.rec_divider);
        dividerItem = new RecyclerDividerItem(drawable);
        databaseReference = FirebaseDatabase.getInstance().getReference();
        setDataTask();

        recyclerView.addOnScrollListener(new RecyclerView.OnScrollListener() {
            @Override
            public void onScrolled(RecyclerView recyclerView, int dx, int dy) {
                super.onScrolled(recyclerView, dx, dy);
                if (dy > 0) {
                    ((Main_Activity) requireActivity()).SetNavigationVisibility(false);
                } else if (dy < 0) {
                    ((Main_Activity) requireActivity()).SetNavigationVisibility(true);
                }
            }
        });
        return view;
    }

    private void setDataTask() {
        class Data extends AsyncTask<Void, Void, Void> {
            @Override
            protected Void doInBackground(Void... voids) {
                databaseReference.child("joiner").child("type").child("decorator").child("district")
                        .addValueEventListener(new ValueEventListener() {
                            @Override
                            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                                modelList = new ArrayList<>();
                                for (DataSnapshot snapshot : dataSnapshot.getChildren()) {
                                    String name = Objects.requireNonNull(snapshot.child("name").getValue()).toString();
                                    String mobile = Objects.requireNonNull(snapshot.child("mobile").getValue()).toString();
                                    String price = Objects.requireNonNull(snapshot.child("price").getValue()).toString();
                                    String address = Objects.requireNonNull(snapshot.child("address").getValue()).toString();
                                    String facility = Objects.requireNonNull(snapshot.child("facility").getValue()).toString();
                                    modelList.add(new DecoModel(name, mobile, facility, price, address, R.drawable.account));
                                }
                                recyclerView.setLayoutManager(new LinearLayoutManager(getContext()));
                                recyclerView.addItemDecoration(dividerItem);
                                dAdapter = new DecoAdapter(modelList, getContext());
                                recyclerView.setAdapter(dAdapter);
                                dAdapter.notifyDataSetChanged();
                            }

                            @Override
                            public void onCancelled(@NonNull DatabaseError databaseError) {

                            }
                        });

                return null;
            }
        }
        Data data = new Data();
        data.execute();
    }
}
