package Fragment;

import android.os.Bundle;

import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.udacity.gradle.band.R;

import java.util.ArrayList;
import java.util.List;

import Adapter.GardnerAdapter;
import Adapter.HallAdapter;
import Model.GardnerModel;
import Model.HallModel;
import ui_design.Main_Activity;

/**
 * A simple {@link Fragment} subclass.
 */
public class GardnerFrag extends Fragment {
    List<GardnerModel> modelList;
    GardnerAdapter gAdapter;
    RecyclerView recyclerView;

    public GardnerFrag() {
        // Required empty public constructor
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_gardner, container, false);
        recyclerView = view.findViewById(R.id.rec_gardner);
        modelList = new ArrayList<>();
        modelList.add(new GardnerModel(R.drawable.account, "Rishi Raj Mishra", "123456789000", "XXXXXXXXXXX", "123450", "XXXXXXXXXX"));
        modelList.add(new GardnerModel(R.drawable.account, "Rishi Raj Mishra", "123456789000", "XXXXXXXXXXX", "123450", "XXXXXXXXXX"));
        modelList.add(new GardnerModel(R.drawable.account, "Rishi Raj Mishra", "123456789000", "XXXXXXXXXXX", "123450", "XXXXXXXXXX"));
        modelList.add(new GardnerModel(R.drawable.account, "Rishi Raj Mishra", "123456789000", "XXXXXXXXXXX", "123450", "XXXXXXXXXX"));
        recyclerView.setLayoutManager(new LinearLayoutManager(view.getContext()));
        gAdapter = new GardnerAdapter(modelList, view.getContext());
        recyclerView.setAdapter(gAdapter);
        gAdapter.notifyDataSetChanged();
        recyclerView.addOnScrollListener(new RecyclerView.OnScrollListener() {
            @Override
            public void onScrolled(RecyclerView recyclerView, int dx, int dy) {
                super.onScrolled(recyclerView, dx, dy);
                if (dy > 0) {
                    ((Main_Activity) requireActivity()).SetNavigationVisibility(false);
                } else if (dy < 0) {
                    ((Main_Activity) requireActivity()).SetNavigationVisibility(true);
                }
            }
        });
        return view;
    }
}
