package Fragment;

import android.os.Bundle;

import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.udacity.gradle.band.R;

import java.util.ArrayList;
import java.util.List;

import Adapter.ChefAdapter;
import Model.ChefModel;
import ui_design.Main_Activity;

/**
 * A simple {@link Fragment} subclass.
 */
public class ChefFragment extends Fragment {
    List<ChefModel> modelList;
    ChefAdapter cAdapter;
    RecyclerView recyclerView;

    public ChefFragment() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_chef, container, false);
        recyclerView = view.findViewById(R.id.rec_chef);
        modelList = new ArrayList<>();
        modelList.add(new ChefModel(R.drawable.account, "xxxxx", "xxxxx", "xxxx", "xxxxx"
                , "xxxxx", "xxxxx"));
        modelList.add(new ChefModel(R.drawable.account, "xxxxx", "xxxxx", "xxxx", "xxxxx"
                , "xxxxx", "xxxxx"));
        modelList.add(new ChefModel(R.drawable.account, "xxxxx", "xxxxx", "xxxx", "xxxxx"
                , "xxxxx", "xxxxx"));
        modelList.add(new ChefModel(R.drawable.account, "xxxxx", "xxxxx", "xxxx", "xxxxx"
                , "xxxxx", "xxxxx"));
        recyclerView.setLayoutManager(new LinearLayoutManager(view.getContext()));
        cAdapter = new ChefAdapter(modelList, view.getContext());
        recyclerView.setAdapter(cAdapter);
        cAdapter.notifyDataSetChanged();
        recyclerView.addOnScrollListener(new RecyclerView.OnScrollListener() {
            @Override
            public void onScrolled(RecyclerView recyclerView, int dx, int dy) {
                super.onScrolled(recyclerView, dx, dy);
                if (dy > 0) {
                    ((Main_Activity) requireActivity()).SetNavigationVisibility(false);
                } else if (dy < 0) {
                    ((Main_Activity) requireActivity()).SetNavigationVisibility(true);
                }
            }
        });
        return view;
    }
}
