package Fragment;

import android.os.Bundle;

import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.udacity.gradle.band.R;

import java.util.ArrayList;
import java.util.List;

import Adapter.HallAdapter;
import Model.HallModel;
import ui_design.Main_Activity;


public class MarriageHall extends Fragment {
    List<HallModel> modelList;
    HallAdapter hAdapter;
    RecyclerView recyclerView;

    public MarriageHall() {

    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_marraige_hall, container, false);
        recyclerView = view.findViewById(R.id.rec_hall);
        modelList = new ArrayList<>();
        recyclerView.setLayoutManager(new LinearLayoutManager(view.getContext()));
        modelList.add(new HallModel(R.drawable.account, "XXXXXXXXXXXXX", "XXXXXXXXXXX"
                , "XXXXXXXXXXXXX", "XXXXXXXXXX", "XXXXXXXX", "XXXXXXXXXXXXXXXx"));
        modelList.add(new HallModel(R.drawable.account, "XXXXXXXXXXXXX", "XXXXXXXXXXX"
                , "XXXXXXXXXXXXX", "XXXXXXXXXX", "XXXXXXXX", "XXXXXXXXXXXXXXXx"));
        modelList.add(new HallModel(R.drawable.account, "XXXXXXXXXXXXX", "XXXXXXXXXXX"
                , "XXXXXXXXXXXXX", "XXXXXXXXXX", "XXXXXXXX", "XXXXXXXXXXXXXXXx"));
        modelList.add(new HallModel(R.drawable.account, "XXXXXXXXXXXXX", "XXXXXXXXXXX"
                , "XXXXXXXXXXXXX", "XXXXXXXXXX", "XXXXXXXX", "XXXXXXXXXXXXXXXx"));
        modelList.add(new HallModel(R.drawable.account, "XXXXXXXXXXXXX", "XXXXXXXXXXX"
                , "XXXXXXXXXXXXX", "XXXXXXXXXX", "XXXXXXXX", "XXXXXXXXXXXXXXXx"));
        hAdapter = new HallAdapter(modelList, view.getContext());
        recyclerView.setAdapter(hAdapter);
        hAdapter.notifyDataSetChanged();
        recyclerView.addOnScrollListener(new RecyclerView.OnScrollListener() {
            @Override
            public void onScrolled(RecyclerView recyclerView, int dx, int dy) {
                super.onScrolled(recyclerView, dx, dy);
                if (dy > 0) {
                    ((Main_Activity) requireActivity()).SetNavigationVisibility(false);
                } else if (dy < 0) {
                    ((Main_Activity) requireActivity()).SetNavigationVisibility(true);
                }
            }
        });
        return view;
    }
}
