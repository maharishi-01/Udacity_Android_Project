package Fragment;

import android.os.Bundle;

import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.udacity.gradle.band.R;

import java.util.ArrayList;
import java.util.List;

import Adapter.Top_MainAdapter;
import Model.HallModel;
import Model.PriestModel;
import Model.Top_MainModel;
import Model.VehicleModel;
import ui_design.Main_Activity;

/**
 * A simple {@link Fragment} subclass.
 */
public class TopTrendHome extends Fragment {

    RecyclerView recyclerView;

    public TopTrendHome() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {

        View view = inflater.inflate(R.layout.fragment_top_trend_home, container, false);

        List<HallModel> modelList = new ArrayList<>();
        List<VehicleModel> list = new ArrayList<>();
        List<PriestModel> pList = new ArrayList<>();
        modelList.add(new HallModel(R.drawable.account, "XXXXXXXXXXXXX", "XXXXXXXXXXX"
                , "XXXXXXXXXXXXX", "XXXXXXXXXX", "XXXXXXXX", "XXXXXXXXXXXXXXXx"));
        modelList.add(new HallModel(R.drawable.account, "XXXXXXXXXXXXX", "XXXXXXXXXXX"
                , "XXXXXXXXXXXXX", "XXXXXXXXXX", "XXXXXXXX", "XXXXXXXXXXXXXXXx"));
        modelList.add(new HallModel(R.drawable.account, "XXXXXXXXXXXXX", "XXXXXXXXXXX"
                , "XXXXXXXXXXXXX", "XXXXXXXXXX", "XXXXXXXX", "XXXXXXXXXXXXXXXx"));
        modelList.add(new HallModel(R.drawable.account, "XXXXXXXXXXXXX", "XXXXXXXXXXX"
                , "XXXXXXXXXXXXX", "XXXXXXXXXX", "XXXXXXXX", "XXXXXXXXXXXXXXXx"));
        modelList.add(new HallModel(R.drawable.account, "XXXXXXXXXXXXX", "XXXXXXXXXXX"
                , "XXXXXXXXXXXXX", "XXXXXXXXXX", "XXXXXXXX", "XXXXXXXXXXXXXXXx"));
        ///
        list.add(new VehicleModel(R.drawable.account, "XXXXXXXXXXXXXXXXXXXXXXX", "XXXXXXXXXXXXXXXXXXXX", "XXXXXXXXXX",
                "XXXXXXXXXXXXXX", "XXXXXXXXXXXXXXXXXXX", "XXXXXXXXXXX"));
        list.add(new VehicleModel(R.drawable.account, "XXXXXXXXXXXXXXXXXXXXXXX", "XXXXXXXXXXXXXXXXXXXX", "XXXXXXXXXX",
                "XXXXXXXXXXXXXX", "XXXXXXXXXXXXXXXXXXX", "XXXXXXXXXXX"));
        list.add(new VehicleModel(R.drawable.account, "XXXXXXXXXXXXXXXXXXXXXXX", "XXXXXXXXXXXXXXXXXXXX", "XXXXXXXXXX",
                "XXXXXXXXXXXXXX", "XXXXXXXXXXXXXXXXXXX", "XXXXXXXXXXX"));
        list.add(new VehicleModel(R.drawable.account, "XXXXXXXXXXXXXXXXXXXXXXX", "XXXXXXXXXXXXXXXXXXXX", "XXXXXXXXXX",
                "XXXXXXXXXXXXXX", "XXXXXXXXXXXXXXXXXXX", "XXXXXXXXXXX"));
        pList.add(new PriestModel(R.drawable.account, "Pandit Rishi Raj Maharaj", "45",
                "Banka District Bakhtiyarpur", "900 per day", "987609876",
                "12 year"));
        pList.add(new PriestModel(R.drawable.account, "Pandit Rishi Raj Maharaj", "45",
                "Banka District Bakhtiyarpur", "900 per day", "987609876",
                "12 year"));
        pList.add(new PriestModel(R.drawable.account, "Pandit Rishi Raj Maharaj", "45",
                "Banka District Bakhtiyarpur", "900 per day", "987609876",
                "12 year"));
        pList.add(new PriestModel(R.drawable.account, "Pandit Rishi Raj Maharaj", "45",
                "Banka District Bakhtiyarpur", "900 per day", "987609876",
                "12 year"));
        recyclerView = view.findViewById(R.id.main_top_rec);
        recyclerView.setLayoutManager(new LinearLayoutManager(view.getContext()));
        List<Top_MainModel> topModel = new ArrayList<>();
        topModel.add(new Top_MainModel(modelList, 0));
        topModel.add(new Top_MainModel(1, list));
        topModel.add(new Top_MainModel(pList,2,"priest top"));

        Top_MainAdapter topAdapter = new Top_MainAdapter(topModel, view.getContext());
        recyclerView.setAdapter(topAdapter);
        topAdapter.notifyDataSetChanged();
        recyclerView.addOnScrollListener(new RecyclerView.OnScrollListener() {
            @Override
            public void onScrolled(RecyclerView recyclerView, int dx, int dy) {
                super.onScrolled(recyclerView, dx, dy);
                if (dy > 0) {
                    ((Main_Activity) requireActivity()).SetNavigationVisibility(false);
                } else if (dy < 0) {
                    ((Main_Activity) requireActivity()).SetNavigationVisibility(true);
                }
            }
        });
        return view;

    }
}
