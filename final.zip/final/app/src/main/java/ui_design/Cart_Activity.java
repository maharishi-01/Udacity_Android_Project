package ui_design;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;

import com.udacity.gradle.band.R;

import java.util.ArrayList;
import java.util.List;

import Adapter.CartAdapter;
import Model.CartModel;

public class Cart_Activity extends AppCompatActivity {
    List<CartModel> modelList;
    CartAdapter adapter;
    RecyclerView recyclerView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cart_);
        recyclerView = findViewById(R.id.cart_recycler);
        modelList = new ArrayList<>();
        modelList.add(new CartModel("Decorator", "boss khan", "4567890", "new-york"));
        modelList.add(new CartModel("Decorator", "boss khan", "4567890", "new-york"));
        modelList.add(new CartModel("Decorator", "boss khan", "4567890", "new-york"));
        modelList.add(new CartModel("Decorator", "boss khan", "4567890", "new-york"));
        adapter = new CartAdapter(modelList, getApplicationContext());
        recyclerView.setAdapter(adapter);
        recyclerView.setLayoutManager(new LinearLayoutManager(getApplicationContext()));
        adapter.notifyDataSetChanged();
    }
}
