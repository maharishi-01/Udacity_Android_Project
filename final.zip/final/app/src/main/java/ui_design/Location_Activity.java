package ui_design;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import android.Manifest;
import android.app.Dialog;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.widget.Button;

import com.google.android.gms.common.ConnectionResult;
import com.google.android.gms.common.GoogleApiAvailability;
import com.udacity.gradle.band.R;

public class Location_Activity extends AppCompatActivity{
    Button current_location;
    static final String FINE_LOCATION = Manifest.permission.ACCESS_FINE_LOCATION;
    static final String COARSE_LOCATION = Manifest.permission.ACCESS_COARSE_LOCATION;
    boolean locationPermissionGranted = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_location);
        current_location = findViewById(R.id.use_current_location);

        if (isServiceOk()) {
            init();
        }
        getLocationPermission();
    }

    private void getLocationPermission() {
        String[] permission = {Manifest.permission.ACCESS_FINE_LOCATION,
                Manifest.permission.ACCESS_COARSE_LOCATION};
        if (ContextCompat.checkSelfPermission(this.getApplicationContext(), FINE_LOCATION) ==
                PackageManager.PERMISSION_GRANTED) {
            if (ContextCompat.checkSelfPermission(this.getApplicationContext(), COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED) {
                locationPermissionGranted = true;
            } else {
                ActivityCompat.requestPermissions(this, permission, 100);
            }
        }

    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        locationPermissionGranted = false;
        switch (requestCode) {
            case 100: {
                if (grantResults.length > 0 ) {
                   for (int i=0;i<grantResults.length;i++)
                   {
                       if (grantResults[i]!=PackageManager.PERMISSION_GRANTED)
                       {
                           locationPermissionGranted=false;
                           return;
                       }
                   }
                    locationPermissionGranted = true;
                    //map initialize
                }
            }
        }
    }

    private void init() {

    }

    public boolean isServiceOk() {
        int available = GoogleApiAvailability.getInstance().
                isGooglePlayServicesAvailable(Location_Activity.this);
        if (available == ConnectionResult.SUCCESS) {
            //fine
            return true;
        } else if (GoogleApiAvailability.getInstance().isUserResolvableError(available)) {
            //an error occur but we can resolve
            Dialog dialog = GoogleApiAvailability.getInstance().getErrorDialog(Location_Activity
                    .this, available, 100);
            dialog.show();
        } else {
            //Map request can't
        }
        return false;
    }
}
