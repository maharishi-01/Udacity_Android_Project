package ui_design;

public class VariableList {
    static  int SPLASH_TIME_OUT=1000;
}
