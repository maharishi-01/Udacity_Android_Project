package ui_design;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import com.udacity.gradle.band.R;

public class PriestDetail extends AppCompatActivity {
    Button send_msg;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_priest_detail);
        send_msg = findViewById(R.id.send_msg);

        send_msg.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                android.telephony.SmsManager sms = android.telephony.SmsManager.getDefault();

            }
        });

    }
}
