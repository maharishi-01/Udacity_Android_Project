package ui_design;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import com.udacity.gradle.band.R;

public class JoinUs_Activity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_join_us);
    }
}
