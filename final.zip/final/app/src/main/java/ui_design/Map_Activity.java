package ui_design;

import androidx.fragment.app.FragmentActivity;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.Spinner;

import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.LatLngBounds;
import com.udacity.gradle.band.R;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;


public class Map_Activity extends FragmentActivity implements OnMapReadyCallback {
    private GoogleMap mMap;
    ArrayList<String> stateList;
    Spinner district_spin, state_spin;
    Button main_page;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_map);
        district_spin = findViewById(R.id.district_spinner);
        state_spin = findViewById(R.id.state_spinner);
        stateList = new ArrayList<>();
        main_page = findViewById(R.id.next);
        try {
            getState();
        } catch (IOException | JSONException e) {
            e.printStackTrace();
        }
        setIndia();
        SupportMapFragment mapFragment = (SupportMapFragment) getSupportFragmentManager()
                .findFragmentById(R.id.map);
        mapFragment.getMapAsync(this);
        main_page.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(Map_Activity.this, Main_Activity.class);
                startActivity(i);
            }
        });
    }

    private void setIndia() {
        if (mMap != null) {
            double bottom = 23.63936;
            double top = 23.63936;
            double left = 68.14712;
            double right = 68.14712;

            LatLngBounds india = new LatLngBounds(new LatLng(33.66, 72.99),
                    new LatLng(33.66,
                    72.99));
            mMap.animateCamera(CameraUpdateFactory.newLatLngBounds(india,1));
            /** MarkerOptions markerOptions = new MarkerOptions();
             markerOptions.position(india.getCenter());
             mMap.addMarker(markerOptions);*/
        }
    }

    private void getState() throws IOException, JSONException {
        String jsonString;
        InputStream inputStream = getAssets().open("state.json");
        int size = inputStream.available();
        byte[] buffer = new byte[size];
        inputStream.read(buffer);
        inputStream.close();
        jsonString = new String(buffer, StandardCharsets.UTF_8);
        JSONObject jsonObject = new JSONObject(jsonString);
        final JSONArray states = jsonObject.getJSONArray("states");
        List<String> stateList = new ArrayList<>();
        for (int i = 0; i < states.length(); i++) {
            String state = states.getJSONObject(i).getString("state");
            stateList.add(state);
        }

        ArrayAdapter<String> stateAdapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_single_choice, stateList);
        state_spin.setAdapter(stateAdapter);
        state_spin.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                String selectedState = (String) parent.getSelectedItem();
                int index = parent.getSelectedItemPosition();
                try {
                    setDistrict(selectedState, states, index);
                } catch (JSONException e) {
                    e.printStackTrace();
                }

            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });
    }

    private void setDistrict(String state, JSONArray states, int index) throws JSONException {
        List<String> dist_list = new ArrayList<>();
        JSONArray districts = states.getJSONObject(index).getJSONArray("districts");
        for (int k = 0; k < districts.length(); k++) {
            dist_list.add(districts.getString(k));
        }
        ArrayAdapter<String> distAdapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_single_choice, dist_list);
        district_spin.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {

            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });
        district_spin.setAdapter(distAdapter);
    }

    @Override
    public void onMapReady(GoogleMap googleMap) {
        mMap = googleMap;
        if (mMap != null) {
            final Handler handler = new Handler();
            handler.postDelayed(new Runnable() {
                @Override
                public void run() {
                    setIndia();

                }
            }, 2000);

        }
    }

}
