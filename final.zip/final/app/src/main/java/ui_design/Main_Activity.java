package ui_design;

import android.app.FragmentManager;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.util.Log;
import android.view.MenuItem;
import android.view.View;

import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.udacity.gradle.band.R;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ShareCompat;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

import Adapter.ItemTypeAdapter;
import Fragment.TopTrendHome;
import Fragment.VehicleFragment;
import Fragment.DecorationFrag;
import Interface.RecyclerViewTouchListener;
import Java.SetItemType;
import Fragment.ChefFragment;
import Fragment.GardnerFrag;
import Fragment.Priest;
import Fragment.MarriageHall;
import Model.ItemTypeModel;

public class Main_Activity extends AppCompatActivity {
    RecyclerView itemListRecycler;
    int index = -1;
    BottomNavigationView navView;
    List<ItemTypeModel> list = new ArrayList<>();
    ItemTypeAdapter adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main_activity);
        navView = findViewById(R.id.nav_view);
        navView.getMenu().getItem(0).setChecked(true);
        itemListRecycler = findViewById(R.id.item_type_recycler);
        firstOpen();
        //SetItemType itemType = new SetItemType(itemListRecycler, getApplicationContext());
        //itemType.setData();
        list.add(new ItemTypeModel(R.drawable.car, "Top Trending"));
        list.add(new ItemTypeModel(R.drawable.car, "Vehicle"));
        list.add(new ItemTypeModel(R.drawable.car, "Marriage Hall"));
        list.add(new ItemTypeModel(R.drawable.car, "Decoration"));
        list.add(new ItemTypeModel(R.drawable.car, "Chef & Cook"));
        list.add(new ItemTypeModel(R.drawable.car, "Gardner"));
        list.add(new ItemTypeModel(R.drawable.car, "Priest"));
        itemListRecycler.setLayoutManager(new LinearLayoutManager(getApplicationContext(), LinearLayoutManager.HORIZONTAL, false));
        adapter = new ItemTypeAdapter(list, getApplicationContext());
        itemListRecycler.setAdapter(adapter);
        adapter.notifyDataSetChanged();


        navView.setOnNavigationItemSelectedListener(new BottomNavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem item) {
                int id = item.getItemId();
                switch (id) {
                    case R.id.home:
                        AppCompatActivity activity = Main_Activity.this;
                        Fragment myFragment = new TopTrendHome();
                        activity.getSupportFragmentManager().beginTransaction().replace(R.id.main_frame, myFragment, "top_trend").commit();
                        navView.getMenu().getItem(0).setChecked(true);
                        return true;
                    case R.id.account:
                        Intent i = new Intent(Main_Activity.this, Account_Activity.class);
                        startActivity(i);
                        return true;
                    case R.id.video:
                        Intent cart_intent = new Intent(Main_Activity.this, Cart_Activity.class);
                        startActivity(cart_intent);
                        return true;

                }
                return true;
            }
        });

        itemListRecycler.addOnItemTouchListener(new RecyclerViewTouchListener(getApplicationContext(),
                itemListRecycler, new RecyclerViewTouchListener.ClickListener() {
            @Override
            public void onClick(View view, int position) {
                if (position == 0 && index != -1) {
                    index = -1;
                    AppCompatActivity activity = (AppCompatActivity) view.getContext();
                    Fragment myFragment = new TopTrendHome();
                    activity.getSupportFragmentManager().beginTransaction().replace(R.id.main_frame, myFragment, "0").commit();
                    navView.getMenu().getItem(0).setChecked(true);
                }
                if (position == 1) {
                    index = position;
                    AppCompatActivity activity = (AppCompatActivity) view.getContext();
                    Fragment myFragment = new VehicleFragment();
                    activity.getSupportFragmentManager().beginTransaction().replace(R.id.main_frame, myFragment, "1").commit();
                    navView.getMenu().getItem(0).setChecked(true);

                }
                if (position == 2) {
                    index = position;
                    AppCompatActivity activity = (AppCompatActivity) view.getContext();
                    Fragment myFragment = new MarriageHall();
                    activity.getSupportFragmentManager().beginTransaction().replace(R.id.main_frame, myFragment, "2").commit();
                    navView.getMenu().getItem(0).setChecked(true);
                }
                if (position == 3) {
                    index = position;
                    AppCompatActivity activity = (AppCompatActivity) view.getContext();
                    Fragment myFragment = new DecorationFrag();
                    activity.getSupportFragmentManager().beginTransaction().replace(R.id.main_frame, myFragment, "3").commit();
                }
                if (position == 4) {
                    AppCompatActivity activity = (AppCompatActivity) view.getContext();
                    Fragment myFragment = new ChefFragment();
                    activity.getSupportFragmentManager().beginTransaction().replace(R.id.main_frame, myFragment, "4").commit();
                    index = position;

                }
                if (position == 5) {
                    AppCompatActivity activity = (AppCompatActivity) view.getContext();
                    Fragment myFragment = new Priest();
                    activity.getSupportFragmentManager().beginTransaction().replace(R.id.main_frame, myFragment, "5").commit();
                    index = position;

                }
                if (position == 6) {
                    index = position;
                    AppCompatActivity activity = (AppCompatActivity) view.getContext();
                    Fragment myFragment = new GardnerFrag();
                    activity.getSupportFragmentManager().beginTransaction().replace(R.id.main_frame, myFragment, "garden").commit();
                }
            }

            @Override
            public void onLongClick(View view, int position) {

            }
        }));
    }

    private void firstOpen() {
        AppCompatActivity activity = Main_Activity.this;
        Fragment myFragment = new TopTrendHome();
        activity.getSupportFragmentManager().beginTransaction().replace(R.id.main_frame, myFragment, "top_trend").commit();
    }

    private void shareApp() {
        ShareCompat.IntentBuilder.from(Main_Activity.this)
                .setType("text/plain")
                .setChooserTitle("Chooser title")
                .setText("http://play.google.com/store/apps/details?id=" + Main_Activity.this.getPackageName())
                .startChooser();
    }

    @Override
    public void onBackPressed() {
        BottomNavigationView bottomNavigationView = (BottomNavigationView) findViewById(R.id.nav_view);
        int selectedItemId = bottomNavigationView.getSelectedItemId();
        if (R.id.home != selectedItemId) {

        } else {
            super.onBackPressed();
        }

    }

    public void SetNavigationVisibility(boolean b) {
        if (b) {
            navView.setVisibility(View.VISIBLE);
        } else {
            navView.setVisibility(View.GONE);
        }
    }
}


