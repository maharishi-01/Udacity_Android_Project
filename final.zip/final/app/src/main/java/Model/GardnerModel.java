package Model;

public class GardnerModel {
    int image;
    String gName,gMob,gAdd,gFee,gFacility;

    public GardnerModel(int image, String gName, String gMob, String gAdd,
                        String gFee, String gFacility) {
        this.image = image;
        this.gName = gName;
        this.gMob = gMob;
        this.gAdd = gAdd;
        this.gFee = gFee;
        this.gFacility = gFacility;
    }

    public int getImage() {
        return image;
    }

    public void setImage(int image) {
        this.image = image;
    }

    public String getgName() {
        return gName;
    }

    public void setgName(String gName) {
        this.gName = gName;
    }

    public String getgMob() {
        return gMob;
    }

    public void setgMob(String gMob) {
        this.gMob = gMob;
    }

    public String getgAdd() {
        return gAdd;
    }

    public void setgAdd(String gAdd) {
        this.gAdd = gAdd;
    }

    public String getgFee() {
        return gFee;
    }

    public void setgFee(String gFee) {
        this.gFee = gFee;
    }

    public String getgFacility() {
        return gFacility;
    }

    public void setgFacility(String gFacility) {
        this.gFacility = gFacility;
    }
}
