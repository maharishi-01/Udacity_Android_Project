package Model;

public class ItemTypeModel {
    int image_url;
    String title;

    public ItemTypeModel(int image_url, String title) {
        this.image_url = image_url;
        this.title = title;
    }

    public int getImage_url() {
        return image_url;
    }

    public void setImage_url(int image_url) {
        this.image_url = image_url;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }
}
