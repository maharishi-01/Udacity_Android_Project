package Model;

public class ChefModel {
    int image;
    String chefHead, chefContact, chefAdd, chefPrice, chefFacility, chefExp;

    public ChefModel(int image, String chefHead, String chefContact, String chefAdd,
                     String chefPrice, String chefFacility, String chefExp) {
        this.image = image;
        this.chefHead = chefHead;
        this.chefContact = chefContact;
        this.chefAdd = chefAdd;
        this.chefPrice = chefPrice;
        this.chefFacility = chefFacility;
        this.chefExp = chefExp;
    }

    public int getImage() {
        return image;
    }

    public void setImage(int image) {
        this.image = image;
    }

    public String getChefHead() {
        return chefHead;
    }

    public void setChefHead(String chefHead) {
        this.chefHead = chefHead;
    }

    public String getChefContact() {
        return chefContact;
    }

    public void setChefContact(String chefContact) {
        this.chefContact = chefContact;
    }

    public String getChefAdd() {
        return chefAdd;
    }

    public void setChefAdd(String chefAdd) {
        this.chefAdd = chefAdd;
    }

    public String getChefPrice() {
        return chefPrice;
    }

    public void setChefPrice(String chefPrice) {
        this.chefPrice = chefPrice;
    }

    public String getChefFacility() {
        return chefFacility;
    }

    public void setChefFacility(String chefFacility) {
        this.chefFacility = chefFacility;
    }

    public String getChefExp() {
        return chefExp;
    }

    public void setChefExp(String chefExp) {
        this.chefExp = chefExp;
    }
}
