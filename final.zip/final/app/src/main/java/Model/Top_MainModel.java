package Model;

import java.util.HashMap;
import java.util.List;

public class Top_MainModel {
    String title;
    List<HallModel> hallModel;
    List<VehicleModel> vehicleModel;
    List<PriestModel> priestModels;
    public final static int HALL = 0;
    public final static int vehicle = 1;
    public final static int PRIEST = 2;

    int type;
    public Top_MainModel(int type, List<VehicleModel> vehicleModel) {
        this.vehicleModel = vehicleModel;
        this.type = type;
    }

    public Top_MainModel(List<HallModel> hallModel, int type) {
        this.hallModel = hallModel;
        this.type = type;
    }

    public List<HallModel> getHallModel() {
        return hallModel;
    }

    public void setHallModel(List<HallModel> hallModel) {
        this.hallModel = hallModel;
    }

    public List<VehicleModel> getVehicleModel() {
        return vehicleModel;
    }

    public void setVehicleModel(List<VehicleModel> vehicleModel) {
        this.vehicleModel = vehicleModel;
    }

    public int getType() {
        return type;
    }

    public void setType(int type) {
        this.type = type;
    }


    public Top_MainModel(List<PriestModel> priestModels, int type, String title) {
        this.priestModels = priestModels;
        this.type = type;
        this.title = title;
    }

    public List<PriestModel> getPriestModels() {
        return priestModels;
    }

    public void setPriestModels(List<PriestModel> priestModels) {
        this.priestModels = priestModels;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }
}
