package Model;

public class PriestModel {
    int image;
    String pName,pAge,pAddress,pFee,pMob,pExpert;

    public PriestModel(int image, String pName, String pAge, String pAddress,
                       String pFee, String pMob, String pExpert) {
        this.image = image;
        this.pName = pName;
        this.pAge = pAge;
        this.pAddress = pAddress;
        this.pFee = pFee;
        this.pMob = pMob;
        this.pExpert = pExpert;
    }

    public int getImage() {
        return image;
    }

    public void setImage(int image) {
        this.image = image;
    }

    public String getpName() {
        return pName;
    }

    public void setpName(String pName) {
        this.pName = pName;
    }

    public String getpAge() {
        return pAge;
    }

    public void setpAge(String pAge) {
        this.pAge = pAge;
    }

    public String getpAddress() {
        return pAddress;
    }

    public void setpAddress(String pAddress) {
        this.pAddress = pAddress;
    }

    public String getpFee() {
        return pFee;
    }

    public void setpFee(String pFee) {
        this.pFee = pFee;
    }

    public String getpMob() {
        return pMob;
    }

    public void setpMob(String pMob) {
        this.pMob = pMob;
    }

    public String getpExpert() {
        return pExpert;
    }

    public void setpExpert(String pExpert) {
        this.pExpert = pExpert;
    }
}
