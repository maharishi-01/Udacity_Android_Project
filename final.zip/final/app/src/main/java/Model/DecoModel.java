package Model;

public class DecoModel {
    String dName,dMob,dFacility,dPrice,dAdd;
    int image;

    public DecoModel(String dName, String dMob, String dFacility, String dPrice, String dAdd, int image) {
        this.dName = dName;
        this.dMob = dMob;
        this.dFacility = dFacility;
        this.dPrice = dPrice;
        this.dAdd = dAdd;
        this.image = image;
    }

    public String getdName() {
        return dName;
    }

    public void setdName(String dName) {
        this.dName = dName;
    }

    public String getdMob() {
        return dMob;
    }

    public void setdMob(String dMob) {
        this.dMob = dMob;
    }

    public String getdFacility() {
        return dFacility;
    }

    public void setdFacility(String dFacility) {
        this.dFacility = dFacility;
    }

    public String getdPrice() {
        return dPrice;
    }

    public void setdPrice(String dPrice) {
        this.dPrice = dPrice;
    }

    public String getdAdd() {
        return dAdd;
    }

    public void setdAdd(String dAdd) {
        this.dAdd = dAdd;
    }

    public int getImage() {
        return image;
    }

    public void setImage(int image) {
        this.image = image;
    }
}
