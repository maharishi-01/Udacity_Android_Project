package Model;

public class VehicleModel {
    int image;
    String ownerName;
    String vAddress;
    String vFee;
    String vMob;

    public int getImage() {
        return image;
    }

    public void setImage(int image) {
        this.image = image;
    }

    public String getOwnerName() {
        return ownerName;
    }

    public void setOwnerName(String ownerName) {
        this.ownerName = ownerName;
    }

    public String getvAddress() {
        return vAddress;
    }

    public void setvAddress(String vAddress) {
        this.vAddress = vAddress;
    }

    public String getvFee() {
        return vFee;
    }

    public void setvFee(String vFee) {
        this.vFee = vFee;
    }

    public String getvMob() {
        return vMob;
    }

    public void setvMob(String vMob) {
        this.vMob = vMob;
    }

    public String getvNumber() {
        return vNumber;
    }

    public void setvNumber(String vNumber) {
        this.vNumber = vNumber;
    }

    public String getvName() {
        return vName;
    }

    public void setvName(String vName) {
        this.vName = vName;
    }

    String vNumber;
    String vName;

    public VehicleModel(int image, String ownerName, String vAddress,
                        String vFee, String vMob, String vNumber, String vName) {
        this.image = image;
        this.ownerName = ownerName;
        this.vAddress = vAddress;
        this.vFee = vFee;
        this.vMob = vMob;
        this.vNumber = vNumber;
        this.vName = vName;
    }

}
