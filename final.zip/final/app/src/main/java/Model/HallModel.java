package Model;

public class HallModel {
    int image;
    String hName,hAddress,hFee,hMob,hPerson,hSpace;

    public HallModel(int image, String hName, String hAddress, String hFee,
                     String hMob, String hPerson, String hSpace) {
        this.image = image;
        this.hName = hName;
        this.hAddress = hAddress;
        this.hFee = hFee;
        this.hMob = hMob;
        this.hPerson = hPerson;
        this.hSpace = hSpace;
    }

    public int getImage() {
        return image;
    }

    public void setImage(int image) {
        this.image = image;
    }

    public String gethName() {
        return hName;
    }

    public void sethName(String hName) {
        this.hName = hName;
    }

    public String gethAddress() {
        return hAddress;
    }

    public void sethAddress(String hAddress) {
        this.hAddress = hAddress;
    }

    public String gethFee() {
        return hFee;
    }

    public void sethFee(String hFee) {
        this.hFee = hFee;
    }

    public String gethMob() {
        return hMob;
    }

    public void sethMob(String hMob) {
        this.hMob = hMob;
    }

    public String gethPerson() {
        return hPerson;
    }

    public void sethPerson(String hPerson) {
        this.hPerson = hPerson;
    }

    public String gethSpace() {
        return hSpace;
    }

    public void sethSpace(String hSpace) {
        this.hSpace = hSpace;
    }
}
