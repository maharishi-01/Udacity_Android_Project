package Adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.udacity.gradle.band.R;

import java.util.List;

import Model.HallModel;
import Model.PriestModel;
import Model.Top_MainModel;
import Model.VehicleModel;

public class Top_MainAdapter extends RecyclerView.Adapter {
    List<Top_MainModel> mainModels;
    Context context;
    RecyclerView.RecycledViewPool pool;

    public Top_MainAdapter(List<Top_MainModel> mainModels, Context context) {
        System.out.println(mainModels.size());
        this.mainModels = mainModels;
        this.context = context;
        pool = new RecyclerView.RecycledViewPool();
    }

    @NonNull
    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        switch (viewType) {
            case Top_MainModel.HALL:
                View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.top_main_custom, parent, false);
                return new HallViewHolder(view);
            case Top_MainModel.vehicle:
                View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.top_main_custom, parent, false);
                return new VehicleViewHolder(v);
            case Top_MainModel.PRIEST:
                View p_view = LayoutInflater.from(parent.getContext()).inflate(R.layout.top_main_custom, parent, false);
                return new PriestViewHolder(p_view);
            default:
                return null;
        }
    }

    @Override
    public void onBindViewHolder(@NonNull RecyclerView.ViewHolder holder, int position) {
        switch (mainModels.get(position).getType()) {
            case Top_MainModel.HALL:
                List<HallModel> hallModels = mainModels.get(position).getHallModel();
                ((HallViewHolder) holder).setData(hallModels);
                break;
            case Top_MainModel.vehicle:
                List<VehicleModel> vehicleModels = mainModels.get(position).getVehicleModel();
                ((VehicleViewHolder) holder).setTopVehicle(vehicleModels);
                break;
            case Top_MainModel.PRIEST:
                List<PriestModel> priestModels = mainModels.get(position).getPriestModels();
                ((PriestViewHolder) holder).setTopPriest(priestModels);
                break;
            default:
                return;
        }
    }

    @Override
    public int getItemViewType(int position) {

        switch (mainModels.get(position).getType()) {
            case 0:
                return Top_MainModel.HALL;

            case 1:
                return Top_MainModel.vehicle;
            case 2:
                return Top_MainModel.PRIEST;
            default:
                return -1;
        }

    }

    @Override
    public int getItemCount() {
        return mainModels.size();
    }

    class HallViewHolder extends RecyclerView.ViewHolder {
        RecyclerView hall_rec;

        public HallViewHolder(@NonNull View itemView) {
            super(itemView);
            hall_rec = itemView.findViewById(R.id.top_main_hall);
        }

        public void setData(List<HallModel> hallModels) {
            HallAdapter hallAdapter = new HallAdapter(hallModels, context);
            hall_rec.setLayoutManager(new LinearLayoutManager(context, RecyclerView.HORIZONTAL, false));
            hall_rec.setAdapter(hallAdapter);
            hallAdapter.notifyDataSetChanged();
        }
    }

    class VehicleViewHolder extends RecyclerView.ViewHolder {

        RecyclerView vec_rec;

        public VehicleViewHolder(@NonNull View itemView) {
            super(itemView);
            vec_rec = itemView.findViewById(R.id.top_main_vehicle);
        }

        public void setTopVehicle(List<VehicleModel> vehicleModels) {
            VehicleAdapter vehicleAdapter = new VehicleAdapter(vehicleModels, context);
            vec_rec.setLayoutManager(new LinearLayoutManager(context, RecyclerView.HORIZONTAL, false));
            vec_rec.setAdapter(vehicleAdapter);
            vehicleAdapter.notifyDataSetChanged();
        }
    }

    class PriestViewHolder extends RecyclerView.ViewHolder {
        RecyclerView priest_rec;

        public PriestViewHolder(@NonNull View itemView) {
            super(itemView);
            priest_rec = itemView.findViewById(R.id.top_main_priest);
        }

        public void setTopPriest(List<PriestModel> priestModels) {
            PriestAdapter priestAdapter = new PriestAdapter(priestModels, context);
            priest_rec.setLayoutManager(new LinearLayoutManager(context, RecyclerView.HORIZONTAL, false));
            priest_rec.setAdapter(priestAdapter);
            priestAdapter.notifyDataSetChanged();
        }
    }
}
