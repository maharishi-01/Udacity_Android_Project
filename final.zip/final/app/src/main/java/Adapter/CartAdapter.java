package Adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.udacity.gradle.band.R;

import java.util.List;

import Model.CartModel;

public class CartAdapter extends RecyclerView.Adapter<CartAdapter.ViewHolder> {
    List<CartModel> models;
    Context context;

    public CartAdapter(List<CartModel> models, Context context) {
        this.models = models;
        this.context = context;
    }

    @NonNull
    @Override
    public CartAdapter.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.cart_custom, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull CartAdapter.ViewHolder holder, int position) {
        String type = models.get(position).getType();
        String name = models.get(position).getName();
        String address = models.get(position).getAddress();
        String mob = models.get(position).getMob();
        holder.setData(type, name, address, mob);
    }

    @Override
    public int getItemCount() {
        return models.size();
    }

    static class ViewHolder extends RecyclerView.ViewHolder {
        TextView cType, cName, cAdd, cMob;
        Button add_book, remove_cart;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            cAdd = itemView.findViewById(R.id.cart_address);
            cType = itemView.findViewById(R.id.cart_category);
            cMob = itemView.findViewById(R.id.cart_mob);
            cName = itemView.findViewById(R.id.cart_name);
            add_book = itemView.findViewById(R.id.cart_book_btn);
            remove_cart = itemView.findViewById(R.id.cart_remove);
        }

        public void setData(String type, String name, String address, String mob) {
            cName.setText(name);
            cType.setText(type);
            cMob.setText(mob);
            cAdd.setText(address);
            add_book.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Toast.makeText(v.getContext(), "Hello", Toast.LENGTH_SHORT).show();
                }
            });
            remove_cart.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Toast.makeText(v.getContext(), "Hii", Toast.LENGTH_SHORT).show();

                }
            });
        }
    }
}
