package Adapter;

import android.content.Context;
import android.graphics.Color;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.recyclerview.widget.RecyclerView;

import com.udacity.gradle.band.R;

import java.util.List;

import Model.ItemTypeModel;

public class ItemTypeAdapter extends RecyclerView.Adapter<ItemTypeAdapter.ViewHolder> {
    List<ItemTypeModel> modelList;
    Context context;
    int index = -1;

    public ItemTypeAdapter(List<ItemTypeModel> modelList, Context context) {
        this.modelList = modelList;
        this.context = context;
    }

    @NonNull
    @Override
    public ItemTypeAdapter.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.top_item_type, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ItemTypeAdapter.ViewHolder holder, final int position) {
        int logoUrl = modelList.get(position).getImage_url();
        String item_name = modelList.get(position).getTitle();
        holder.setData(logoUrl, item_name, position);
        if (position == 0) {
            holder.logoImage.setBackgroundColor(Color.YELLOW);
            holder.constraintLayout.setBackgroundColor(Color.RED);
        }
        /**  holder.constraintLayout.setOnClickListener(new View.OnClickListener() {
        @Override public void onClick(View v) {
        index = position;
        notifyDataSetChanged();
        }
        });
         if (index == position) {
         holder.logoImage.setBackgroundColor(Color.parseColor("#567845"));
         } else {
         holder.logoImage.setBackgroundColor(Color.parseColor("#ffffff"));
         }*/

    }

    @Override
    public int getItemCount() {
        return modelList.size();
    }

    static class ViewHolder extends RecyclerView.ViewHolder {
        ImageView logoImage;
        TextView itemName;
        ConstraintLayout constraintLayout;

        public ViewHolder(@NonNull final View itemView) {
            super(itemView);
            logoImage = itemView.findViewById(R.id.item_logo);
            itemName = itemView.findViewById(R.id.item_name);
            constraintLayout = itemView.findViewById(R.id.constraint_main_custom);
        }

        public void setData(int logoUrl, String item_name, int position) {
            logoImage.setImageResource(logoUrl);
            itemName.setText(item_name);

        }
    }
}
