package Adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.udacity.gradle.band.R;

import java.util.List;

import Model.ChefModel;
import de.hdodenhof.circleimageview.CircleImageView;

public class ChefAdapter extends RecyclerView.Adapter<ChefAdapter.ViewHolder> {
    List<ChefModel> models;
    Context context;

    public ChefAdapter(List<ChefModel> models, Context context) {
        this.models = models;
        this.context = context;
    }

    @NonNull
    @Override
    public ChefAdapter.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.rec_chef_custom, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ChefAdapter.ViewHolder holder, int position) {
        int image = models.get(position).getImage();
        String name = models.get(position).getChefHead();
        String contact = models.get(position).getChefContact();
        String add = models.get(position).getChefAdd();
        String exp = models.get(position).getChefExp();
        String fee = models.get(position).getChefPrice();
        String facility = models.get(position).getChefFacility();
        holder.setData(image, name, contact, add, exp, fee, facility);
    }

    @Override
    public int getItemCount() {
        return models.size();
    }

    static class ViewHolder extends RecyclerView.ViewHolder {
        CircleImageView imageView;
        TextView cName, cFee, cFacility, cContact, cAdd, cExp;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            imageView = itemView.findViewById(R.id.rec_chef_image);
            cName = itemView.findViewById(R.id.rec_chef_head);
            cFee = itemView.findViewById(R.id.rec_chef_cost);
            cFacility = itemView.findViewById(R.id.rec_chef_facility);
            cContact = itemView.findViewById(R.id.rec_chef_mob);
            cAdd = itemView.findViewById(R.id.rec_chef_add);
            cExp = itemView.findViewById(R.id.rec_chef_exp);
        }

        void setData(int image, String name, String contact, String add, String exp, String fee, String facility) {
            imageView.setImageResource(image);
            cName.setText(name);
            cFacility.setText(facility);
            cFee.setText(fee);
            cContact.setText(contact);
            cAdd.setText(add);
            cExp.setText(exp);
        }
    }
}
