package Adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.udacity.gradle.band.R;

import java.util.List;

import Model.GardnerModel;
import de.hdodenhof.circleimageview.CircleImageView;

public class GardnerAdapter extends RecyclerView.Adapter<GardnerAdapter.ViewHolder> {

    List<GardnerModel> models;
    Context context;

    public GardnerAdapter(List<GardnerModel> models, Context context) {
        this.models = models;
        this.context = context;
    }

    @NonNull
    @Override
    public GardnerAdapter.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.rec_gardner_custom, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull GardnerAdapter.ViewHolder holder, int position) {
        int image = models.get(position).getImage();
        String name = models.get(position).getgName();
        String add = models.get(position).getgAdd();
        String facility = models.get(position).getgFacility();
        String fee = models.get(position).getgFee();
        String mob = models.get(position).getgMob();
        holder.setData(image, name, add, facility, fee, mob);


    }

    @Override
    public int getItemCount() {
        return models.size();
    }

    class ViewHolder extends RecyclerView.ViewHolder {
        CircleImageView imageView;
        TextView gName, gMobile, gAddress, gFacility, gFee;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            imageView = itemView.findViewById(R.id.rec_gImage);
            gName = itemView.findViewById(R.id.rec_gName);
            gAddress = itemView.findViewById(R.id.rec_gAddress);
            gFacility = itemView.findViewById(R.id.rec_gFacility);
            gFee = itemView.findViewById(R.id.rec_gFee);
            gMobile = itemView.findViewById(R.id.rec_gMob);
        }

        public void setData(int image, String name, String add, String facility, String fee, String mob) {
            imageView.setImageResource(image);
            gMobile.setText(mob);
            gFee.setText(fee);
            gFacility.setText(facility);
            gAddress.setText(add);
            gName.setText(name);

        }
    }
}
