package Adapter;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.udacity.gradle.band.R;

import java.util.List;

import Model.HallModel;
import de.hdodenhof.circleimageview.CircleImageView;
import ui_design.HallDetail;

public class HallAdapter extends RecyclerView.Adapter<HallAdapter.ViewHolder> {
    List<HallModel> models;
    Context context;

    public HallAdapter(List<HallModel> models, Context context) {
        this.models = models;
        this.context = context;
    }

    @NonNull
    @Override
    public HallAdapter.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.marriage_hall_custom, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull HallAdapter.ViewHolder holder, int position) {
        String name = models.get(position).gethName();
        String address = models.get(position).gethAddress();
        String fee = models.get(position).gethFee();
        String mob = models.get(position).gethMob();
        int image = models.get(position).getImage();
        String con_person = models.get(position).gethPerson();
        String space = models.get(position).gethSpace();
        holder.setData(name, address, fee, mob, image, con_person, space);
    }

    @Override
    public int getItemCount() {
        return models.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        CircleImageView imageView;
        TextView hName, hAddress, hFee, hMob, hContactPer, hSpace;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            hAddress = itemView.findViewById(R.id.rec_hall_add);
            hContactPer = itemView.findViewById(R.id.rec_hall_conPer);
            hFee = itemView.findViewById(R.id.rec_hall_fee);
            hName = itemView.findViewById(R.id.rec_hall_name);
            hMob = itemView.findViewById(R.id.rec_hall_conNum);
            imageView = itemView.findViewById(R.id.rec_hall_image);
            hSpace = itemView.findViewById(R.id.rec_hall_space);
        }

        public void setData(String name, String address, String fee, String mob, int image,
                            String con_person, String space) {
            imageView.setImageResource(image);
            hMob.setText(mob);
            hName.setText(name);
            hFee.setText(fee);
            hAddress.setText(address);
            hContactPer.setText(con_person);
            hSpace.setText(space);
            itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Intent i = new Intent(context, HallDetail.class);
                    context.startActivity(i);
                }
            });
        }
    }
}
