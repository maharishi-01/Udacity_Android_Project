package Adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.udacity.gradle.band.R;

import java.util.List;

import Model.DecoModel;
import de.hdodenhof.circleimageview.CircleImageView;

public class DecoAdapter extends RecyclerView.Adapter<DecoAdapter.ViewHolder> {
    List<DecoModel> models;
    Context context;

    public DecoAdapter(List<DecoModel> models, Context context) {
        this.models = models;
        this.context = context;
    }

    @NonNull
    @Override
    public DecoAdapter.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.rec_deco_custom, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull DecoAdapter.ViewHolder holder, int position) {
        int image = models.get(position).getImage();
        String name = models.get(position).getdName();
        String mob = models.get(position).getdMob();
        String add = models.get(position).getdAdd();
        String facility = models.get(position).getdFacility();
        String fee = models.get(position).getdPrice();
        holder.setData(image, name, mob, add, facility, fee);
    }

    @Override
    public int getItemCount() {
        return models.size();
    }

    static class ViewHolder extends RecyclerView.ViewHolder {
        CircleImageView imageView;
        TextView dName, dFacility, dFee, dMob, dAdd;

        ViewHolder(@NonNull View itemView) {
            super(itemView);
            imageView = itemView.findViewById(R.id.rec_dec_image);
            dName = itemView.findViewById(R.id.rec_dec_name);
            dFee = itemView.findViewById(R.id.rec_dec_fee);
            dFacility = itemView.findViewById(R.id.rec_dec_facility);
            dMob = itemView.findViewById(R.id.rec_dec_mob);
            dAdd = itemView.findViewById(R.id.rec_dec_add);
        }

        public void setData(int image, String name, String mob, String add, String facility, String fee) {
            imageView.setImageResource(image);
            dName.setText(name);
            dFacility.setText(facility);
            dFee.setText(fee);
            dMob.setText(mob);
            dAdd.setText(add);
        }
    }
}
