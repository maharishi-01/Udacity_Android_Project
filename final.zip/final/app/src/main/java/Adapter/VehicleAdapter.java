package Adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.udacity.gradle.band.R;

import java.util.List;

import Model.VehicleModel;
import de.hdodenhof.circleimageview.CircleImageView;

public class VehicleAdapter extends RecyclerView.Adapter<VehicleAdapter.ViewHolder> {
    List<VehicleModel> models;
    Context context;

    public VehicleAdapter(List<VehicleModel> models, Context context) {
        this.models = models;
        this.context = context;
    }

    @NonNull
    @Override
    public VehicleAdapter.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.vehicle_custom, parent, false);
        return new VehicleAdapter.ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull VehicleAdapter.ViewHolder holder, int position) {
        String vec_type = models.get(position).getvName();
        String address = models.get(position).getvAddress();
        String fee = models.get(position).getvFee();
        String mob = models.get(position).getvMob();
        int image = models.get(position).getImage();
        String owner_name = models.get(position).getOwnerName();
        String num_plate = models.get(position).getvNumber();
        holder.setData(vec_type, address, fee, mob, image, owner_name, num_plate);

    }

    @Override
    public int getItemCount() {
        return models.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        CircleImageView imageView;
        TextView vName, vAddress, vFee, vMob, ownerName, vNumber;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            vAddress = itemView.findViewById(R.id.rec_vec_address);
            vFee = itemView.findViewById(R.id.rec_vec_fee);
            vMob = itemView.findViewById(R.id.rec_vec_mobile);
            vName = itemView.findViewById(R.id.rec_vec_type);
            vNumber = itemView.findViewById(R.id.rec_num_plate);
            ownerName = itemView.findViewById(R.id.rec_owner_name);
            imageView = itemView.findViewById(R.id.rec_vec_ownerImage);
        }

        public void setData(String vec_type, String address, String fee, String mob,
                            int image, String owner_name, String num_plate) {
         imageView.setImageResource(image);
         vAddress.setText(address);
         vFee.setText(fee);
         vMob.setText(mob);
         ownerName.setText(owner_name);
         vNumber.setText(num_plate);
         vName.setText(vec_type);
        }
    }
}
