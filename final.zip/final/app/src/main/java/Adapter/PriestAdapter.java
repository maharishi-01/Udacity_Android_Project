package Adapter;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.udacity.gradle.band.R;

import java.util.List;

import Model.PriestModel;
import de.hdodenhof.circleimageview.CircleImageView;
import ui_design.PriestDetail;

public class PriestAdapter extends RecyclerView.Adapter<PriestAdapter.ViewHolder> {
    List<PriestModel> models;
    Context context;

    public PriestAdapter(List<PriestModel> models, Context context) {
        this.models = models;
        this.context = context;
    }

    @NonNull
    @Override
    public PriestAdapter.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.priest_custom, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull PriestAdapter.ViewHolder holder, int position) {
        String name = models.get(position).getpName();
        String address = models.get(position).getpAddress();
        String age = models.get(position).getpAge();
        String expert = models.get(position).getpExpert();
        String fee = models.get(position).getpFee();
        String mob = models.get(position).getpMob();
        int image = models.get(position).getImage();
        holder.setData(name, address, age, expert, fee, mob, image);
    }

    @Override
    public int getItemCount() {
        return models.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        CircleImageView imageView;
        TextView pName, pAddress, pAge, pFee, pMob, pExpert;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            pAddress = itemView.findViewById(R.id.priest_add);
            pAge = itemView.findViewById(R.id.priest_age);
            pExpert = itemView.findViewById(R.id.priest_experience);
            pFee = itemView.findViewById(R.id.priest_fee);
            pName = itemView.findViewById(R.id.priestName);
            pMob = itemView.findViewById(R.id.priest_mob);
            imageView = itemView.findViewById(R.id.priest_rec_image);

        }

        public void setData(String name, String address, String age, String expert, String fee,
                            String mob, int image) {
            imageView.setImageResource(image);
            pMob.setText(mob);
            pName.setText(name);
            pFee.setText(fee);
            pAddress.setText(address);
            pAge.setText(age);
            pExpert.setText(expert);
            itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Intent i = new Intent(context, PriestDetail.class);
                    context.startActivity(i);
                }
            });
        }

    }
}
