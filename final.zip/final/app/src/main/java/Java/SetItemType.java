package Java;

import android.content.Context;
import android.graphics.Color;

import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.udacity.gradle.band.R;

import java.util.ArrayList;
import java.util.List;

import Adapter.ItemTypeAdapter;
import Model.ItemTypeModel;

public class SetItemType {
    RecyclerView recyclerView;
    Context context;
    List<ItemTypeModel> list = new ArrayList<>();
    ItemTypeAdapter adapter;

    public SetItemType(RecyclerView recyclerView, Context context) {
        this.recyclerView = recyclerView;
        this.context = context;
    }

    public void setData() {
        list.add(new ItemTypeModel(R.drawable.car, "Top Trending"));
        list.add(new ItemTypeModel(R.drawable.car, "Vehicle"));
        list.add(new ItemTypeModel(R.drawable.car, "Marriage Hall"));
        list.add(new ItemTypeModel(R.drawable.car, "Decoration"));
        list.add(new ItemTypeModel(R.drawable.car, "Chef & Cook"));
        list.add(new ItemTypeModel(R.drawable.car, "Gardner"));
        list.add(new ItemTypeModel(R.drawable.car, "Priest"));
        recyclerView.setLayoutManager(new LinearLayoutManager(context, LinearLayoutManager.HORIZONTAL, false));
        adapter = new ItemTypeAdapter(list, context);
        recyclerView.setAdapter(adapter);
        adapter.notifyDataSetChanged();
    }

}
