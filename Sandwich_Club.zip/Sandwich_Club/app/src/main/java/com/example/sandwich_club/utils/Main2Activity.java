package com.example.sandwich_club.utils;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import com.example.sandwich_club.R;

public class Main2Activity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);
    }
}
