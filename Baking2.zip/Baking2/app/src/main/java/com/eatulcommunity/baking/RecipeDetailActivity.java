package com.eatulcommunity.baking;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.os.Parcelable;
import android.preference.PreferenceManager;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;

import com.google.gson.Gson;

import java.util.ArrayList;
import java.util.List;

public class RecipeDetailActivity extends AppCompatActivity implements RecipeDetailAdapter
        .ListItemClickListener,RecipeStepDetailFragment.ListItemClickListener{

    public static String SELECTED_STEPS="Selected_Steps";
    public static String SELECTED_INDEX="Selected_Index";
    static String STACK_RECIPE_DETAIL="STACK_RECIPE_DETAIL";
    public static String STACK_RECIPE_STEP_DETAIL="STACK_RECIPE_STEP_DETAIL";

    Toolbar myToolbar;
    private ArrayList<Recipe> recipe;
    private List<Steps> stepsArrayList;
    private List<Ingredients> ingredientsList;
    String recipeName;
    String ingredients;

    //private boolean mTwoPane;

    @SuppressLint("ResourceType")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_recipe_detail);


        if(savedInstanceState == null){

            Bundle b = getIntent().getExtras();

            recipe = new ArrayList<>();
            recipe = b.getParcelableArrayList("recipe");
            recipeName = recipe.get(0).getRecipeName();
            stepsArrayList = recipe.get(0).getSteps();
            ingredientsList = recipe.get(0).getIngredients();



            ingredients = new Gson().toJson(ingredientsList);

            PreferenceManager.getDefaultSharedPreferences(this)
                    .edit().putString("ingredients",ingredients)
                    .apply();
            //addIngredients(ingredients);


            final RecipeDetailFragment recipeDetailFragment = new RecipeDetailFragment();
            recipeDetailFragment.setArguments(b);
            getSupportFragmentManager()
                    .beginTransaction()
                    .add(R.id.container,recipeDetailFragment)
                    .commit();


            if(findViewById(R.layout.fragment_recipe_detail) != null){
                //mTwoPane = true;

                final RecipeStepDetailFragment recipeStepDetailFragmentTablet = new RecipeStepDetailFragment();

                Bundle stepBundle = new Bundle();
                stepBundle.putParcelableArrayList(SELECTED_STEPS, (ArrayList<? extends Parcelable>) stepsArrayList);
                //stepBundle.putInt(SELECTED_INDEX,clickedItemIndex);
                recipeStepDetailFragmentTablet.setArguments(stepBundle);

                recipeStepDetailFragmentTablet.setArguments(stepBundle);
                getSupportFragmentManager()
                        .beginTransaction()
                        .add(R.layout.fragment_recipe_step_detail,recipeStepDetailFragmentTablet)
                        .commit();


            }

            myToolbar = (Toolbar) findViewById(R.id.toolbar);
            getSupportActionBar().setHomeButtonEnabled(true);
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
            getSupportActionBar().setTitle(recipeName);

        }else{

            //mTwoPane = false;
            recipeName = savedInstanceState.getString("recipeName");

            myToolbar = (Toolbar) findViewById(R.id.toolbar);
            getSupportActionBar().setHomeButtonEnabled(true);
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
            getSupportActionBar().setTitle(recipeName);
        }

    }



    @SuppressLint("ResourceType")
    @Override
    public void onListItemClick(List<Steps> steps, int clickedItemIndex) {

        final RecipeStepDetailFragment fragment = new RecipeStepDetailFragment();
        FragmentManager fm = getSupportFragmentManager();
        FragmentTransaction ft = fm.beginTransaction();

        Bundle stepBundle = new Bundle();
        stepBundle.putParcelableArrayList(SELECTED_STEPS,(ArrayList<Steps>) steps);
        stepBundle.putInt(SELECTED_INDEX,clickedItemIndex);
        fragment.setArguments(stepBundle);

        if(findViewById(R.layout.fragment_recipe_detail) != null){
            ft.replace(R.layout.fragment_recipe_step_detail,fragment);
            ft.setTransition(FragmentTransaction.TRANSIT_FRAGMENT_FADE);
            ft.addToBackStack(STACK_RECIPE_STEP_DETAIL);
            ft.commit();

        }else {
            ft.replace(R.id.container, fragment);
            ft.setTransition(FragmentTransaction.TRANSIT_FRAGMENT_FADE);
            ft.addToBackStack(STACK_RECIPE_STEP_DETAIL);
            ft.commit();
        }

    }

    @Override
    public void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);
        outState.putParcelableArrayList("recipeList",recipe);
        outState.putString("recipeName",recipeName);
    }


}
