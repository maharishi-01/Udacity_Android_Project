package com.eatulcommunity.baking;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;

import androidx.fragment.app.Fragment;
import androidx.loader.app.LoaderManager;
import androidx.loader.content.Loader;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.List;

public class MainActivityFragment extends Fragment
        implements LoaderManager.LoaderCallbacks<Object>{

    public static final String LOG_TAG = "MainActivityFragment";
    public static final int RECIPE_LOADER_ID = 0;
    private String recipeUrl;

    private List<Recipe> mRecipeList;
    private RecyclerView mRecyclerView;
    private RecipeAdapter mRecipeAdapter;

    public MainActivityFragment() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment

        View view = inflater.inflate(R.layout.main_fragment, container, false);
        getLoaderManager().initLoader(RECIPE_LOADER_ID,null,this);

        mRecipeList = new ArrayList<>();

        mRecyclerView = view.findViewById(R.id.recipe_recycler_view);

        mRecipeAdapter = new RecipeAdapter(getActivity(),(MainActivity)getActivity(),mRecipeList);
        mRecyclerView.setAdapter(mRecipeAdapter);

        if (view.getTag()!=null && view.getTag().equals("phone-land")){
            GridLayoutManager mLayoutManager = new GridLayoutManager(getContext(),4);
            mRecyclerView.setLayoutManager(mLayoutManager);
        }
        else {
            LinearLayoutManager mLayoutManager = new LinearLayoutManager(getContext());
            mRecyclerView.setLayoutManager(mLayoutManager);

        }

        return view;
    }

    @Override
    public Loader onCreateLoader(int id, Bundle args) {

        if(id == RECIPE_LOADER_ID){
            recipeUrl = "https://d17h27t6h515a5.cloudfront.net/topher/2017/May/59121517_baking/baking.json";

            return new RecipeLoader(getActivity(),recipeUrl);

        }

        return null;
    }

    @Override
    public void onLoadFinished(Loader<Object> loader, Object data) {
        int id = loader.getId();

        if(id == RECIPE_LOADER_ID){
            mRecipeList = (ArrayList<Recipe>)data;
            if(mRecipeList != null && !mRecipeList.isEmpty()){
                mRecipeAdapter.setRecipeData(mRecipeList);
            }else{
                Toast.makeText(getActivity(),"No data retrieved from the server",Toast.LENGTH_LONG).show();
            }
        }
    }

    @Override
    public void onLoaderReset(Loader<Object> loader) {

    }


}

