package com.example.popular_movies_part2;

import androidx.lifecycle.ViewModel;
import androidx.lifecycle.ViewModelProvider;

public class DetailsMovieViewFactory extends ViewModelProvider.NewInstanceFactory {
    private final AppDatabase mDb;
    private final int mMovieId;

    public DetailsMovieViewFactory(AppDatabase database, int movieId) {
        mDb = database;
        mMovieId = movieId;
    }
    @Override
    public <T extends ViewModel> T create(Class<T> modelClass) {
        return (T) new MovieDetailsViewModel(mDb, mMovieId);

    }
}

