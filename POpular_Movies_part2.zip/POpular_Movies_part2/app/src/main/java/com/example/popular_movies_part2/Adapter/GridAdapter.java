package com.example.popular_movies_part2.Adapter;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.popular_movies_part2.DetailsActivity;
import com.example.popular_movies_part2.MyDataList;
import com.example.popular_movies_part2.R;
import com.squareup.picasso.Picasso;

public class GridAdapter extends RecyclerView.Adapter<GridAdapter.Holder> {
    private static MyDataList[]mMovies;
    private Context mContext;

    public GridAdapter(Context mContext, MyDataList[] mMovies) {
        this.mMovies = mMovies;

        if (mContext == null) {
            try{
                Thread.sleep(1000);
            } catch(InterruptedException exception){
                exception.printStackTrace();
            }
        } else {
            this.mContext = mContext;
        }
    }

    public class Holder extends RecyclerView.ViewHolder {
        public ImageView mImageView;

        public Holder(ImageView v) {
            super(v);
            mImageView = v;
        }
    }
    @NonNull
    @Override
    // Create new views (Invoked by the Layout Manager)
    public GridAdapter.Holder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {

        // Create a new view
        ImageView v = (ImageView) LayoutInflater.from(parent.getContext ())
                .inflate (R.layout.main_thumb, parent, false);

        Holder vh = new Holder (v);
        return vh;
    }

    @Override
    // Replace the contents of a view (Invoked by the layout manager)
    public void onBindViewHolder(@NonNull Holder holder, int position) {
        Picasso.get().load(mMovies[position].getPosterPath())
                .fit()
                .error(R.mipmap.ic_launcher)
                .placeholder(R.mipmap.ic_launcher_round)
                .into((ImageView) holder.mImageView.findViewById(R.id.image_view));
        holder.mImageView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(mContext, DetailsActivity.class);
                intent.putExtra("movie", mMovies[position]);
                System.out.println("hello"+ mMovies[position]);
                intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                mContext.startActivity(intent);
            }
        });

    }

    @Override
    public int getItemCount() {
        if (mMovies == null || mMovies.length == 0) {
            return -1;
        }
        return mMovies.length;
    }

    public void setMovies(MyDataList[] movies) {
        mMovies = movies;
    }



}
