package com.example.popular_movies_part2;

import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;
import androidx.lifecycle.ViewModelProviders;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Parcelable;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.example.popular_movies_part2.Adapter.GridAdapter;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public class MainActivity extends AppCompatActivity {
    String url = "https://api.themoviedb.org/3/movie/top_rated?api_key=fed2db369405f1ec521c5b09c3fd3599";

    GridAdapter adapter;
    private RecyclerView mRecyclerView;
    private RecyclerView.LayoutManager mLayoutManager;
    private AppDatabase mDb;
    private int selectedItem;
    private Parcelable mListState;
    private MenuItem menuItem;
    private MyDataList[] movies;
    ActionBar actionBar;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        mRecyclerView = findViewById(R.id.recycler_view);
        mLayoutManager = new GridLayoutManager(this, 2);
        mRecyclerView.getRecycledViewPool().clear();
        mRecyclerView.setLayoutManager(mLayoutManager);
        actionBar=getSupportActionBar();

        mDb = AppDatabase.getInstance(getApplicationContext());
        if (savedInstanceState != null) {
            selectedItem = savedInstanceState.getInt("OPTION");
        }
        actionBar.setTitle("Popular");
        loadData load = new loadData();
        load.execute("popular");

    }

    @Override
    protected void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);

        outState.putInt("OPTION", selectedItem);
        mListState = mLayoutManager.onSaveInstanceState();
        outState.putParcelable("LIST_STATE_KEY", mListState);
    }

    @Override
    protected void onRestoreInstanceState(Bundle outState) {
        selectedItem = outState.getInt("OPTION");
        if (outState != null) {
            mListState = outState.getParcelable("LIST_STATE_KEY");
        }

    }

    @Override
    protected void onResume() {
        super.onResume();

        if (mListState != null) {
            mLayoutManager.onRestoreInstanceState(mListState);
        }
    }


    public class loadData extends AsyncTask<String, Void, Void> {
        @Override
        protected Void doInBackground(String... strings) {

            final StringRequest request = new StringRequest(Request.Method.POST,
                    "https://api.themoviedb.org/3/movie/" + strings[0] + "?api_key=fed2db369405f1ec521c5b09c3fd3599", new Response.Listener<String>() {
                @Override
                public void onResponse(String response) {
                    try {
                        JSONObject object = new JSONObject(response);
                        System.out.println(response);
                        JSONArray array = object.getJSONArray("results");
                        movies = new MyDataList[array.length()];

                        if (array.isNull(0)) {

                        } else {
                            for (int i = 0; i < array.length(); i++) {
                                movies[i]=new MyDataList();
                                JSONObject temp = array.getJSONObject(i);
                                movies[i].setMovieId(Integer.parseInt(temp.getString("id")));
                                movies[i].setVoterAverage(temp.getString("vote_average"));
                                movies[i].setOriginalTitle(temp.getString("title"));
                                movies[i].setReleaseDate(temp.getString("release_date"));
                                movies[i].setPosterPath("https://image.tmdb.org/t/p/w342"+temp.getString("poster_path"));
                                movies[i].setOverview(temp.getString("overview"));
                            }
                            adapter = new GridAdapter(getApplicationContext(), movies);
                            mRecyclerView.setAdapter(adapter);
                        }
                    } catch (JSONException e) {
                        e.printStackTrace();
                    }
                }
            }, new Response.ErrorListener() {
                @Override
                public void onErrorResponse(VolleyError error) {

                }
            });
            RequestQueue requestQueue = Volley.newRequestQueue(MainActivity.this);
            requestQueue.add(request);
            return null;
        }

        @Override
        protected void onPostExecute(Void string) {

        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.preference_menu, menu);
        switch (selectedItem) {
            case R.id.popular_setting:

            case R.id.favorite_movie_setting:
                menuItem = menu.findItem(R.id.popular_setting);
                menuItem.setChecked(true);
                break;

            case R.id.top_rated_setting:
                menuItem = menu.findItem(R.id.top_rated_setting);
                menuItem.setChecked(true);
                break;
        }
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();
        if (id == R.id.popular_setting) {
            selectedItem = id;
            item.setVisible(true);
            loadData load = new loadData();
            load.execute("popular");
            actionBar.setTitle("Popular");
            return true;
        }
        if (id == R.id.top_rated_setting) {
            actionBar.setTitle("Top Rated");
            selectedItem = id;
            item.setVisible(true);
            loadData load = new loadData();
            load.execute("top_rated");
            return true;
        }
        if (id == R.id.favorite_movie_setting) {
            actionBar.setTitle("Favorite");
            selectedItem = id;
            item.setVisible(true);
            setUpViewModel();
            return true;
        }

        return super.onOptionsItemSelected(item);
    }

        public void setUpViewModel() {
            MainViewModel viewModel = ViewModelProviders.of(this).get(MainViewModel.class);
            viewModel.getMovies ().observe (this, (MyDataList[] moviesList) -> {
                if(moviesList.length==0)
                {
                    Toast.makeText(this, "No Data Present Please Add Some Movie", Toast.LENGTH_SHORT).show();
                }
                adapter.notifyDataSetChanged ();
                adapter.setMovies (moviesList);
            });

    }


}
