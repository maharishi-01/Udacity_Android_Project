package com.example.popular_movies_part2.Adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.example.popular_movies_part2.R;
import com.example.popular_movies_part2.reviewModel;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class reviewAdapter extends RecyclerView.Adapter<reviewAdapter.Holder> {
   List<reviewModel>list;
   Context context;

    public reviewAdapter(List<reviewModel> list, Context context) {
        this.list = list;
        this.context = context;
    }

    @NonNull
    @Override
    public reviewAdapter.Holder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v=LayoutInflater.from(parent.getContext()).inflate(R.layout.custom_review, parent, false);
        return new Holder(v);
    }

    @Override
    public void onBindViewHolder(@NonNull Holder holder, int position) {
         String author=list.get(position).getAuthor();
         String content=list.get(position).getContent();
         String url=list.get(position).getUrl();
         holder.setData(author,content,url);
    }

    @Override
    public int getItemCount() {
        return list.size();
    }
    public class Holder extends RecyclerView.ViewHolder{
         TextView A,C,U;

        public Holder(@NonNull View itemView) {
            super(itemView);
            A=itemView.findViewById(R.id.author);
            C=itemView.findViewById(R.id.content);
            U=itemView.findViewById(R.id.url);
        }

        public void setData(String author, String content, String url) {
            A.setText(author);
            C.setText(content);
            U.setText(url);
        }
    }
}
