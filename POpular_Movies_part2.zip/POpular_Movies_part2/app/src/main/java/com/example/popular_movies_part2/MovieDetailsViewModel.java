package com.example.popular_movies_part2;

import androidx.lifecycle.LiveData;
import androidx.lifecycle.ViewModel;

public class MovieDetailsViewModel extends ViewModel {
    LiveData<MyDataList>dataListLiveData;
    MovieDetailsViewModel(AppDatabase appDatabase,int movieId)
    {
        dataListLiveData=appDatabase.movieDao().loadMovieById(movieId);
    }
    public LiveData<MyDataList> getMovie() {
        return dataListLiveData;
    }

}
