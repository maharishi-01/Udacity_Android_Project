package com.example.popular_movies_part2;

import androidx.annotation.Nullable;
import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.NavUtils;
import androidx.lifecycle.Observer;
import androidx.lifecycle.ViewModelProviders;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.graphics.Color;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.MenuItem;
import android.widget.CompoundButton;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.ToggleButton;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;
import com.example.popular_movies_part2.Adapter.reviewAdapter;
import com.example.popular_movies_part2.Adapter.trailerAdapter;
import com.squareup.picasso.Picasso;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

public class DetailsActivity extends AppCompatActivity {
    TextView desc, rate, release, title;
    ToggleButton favoriteBtn;
    ImageView posture;
    RecyclerView recyclerView, review_recycler;
    trailerAdapter adapter;
    List<trailerModel> model_list;
    List<reviewModel> reviewModels;
    reviewAdapter re_adapter;
    String findUrl = "https://api.themoviedb.org/3/movie/";
    String api_key = "fed2db369405f1ec521c5b09c3fd3599";
    private AppDatabase mDb;
    ActionBar actionBar;
    MyDataList movie;
    String id;

    @SuppressLint("ClickableViewAccessibility")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_details);
        actionBar = this.getSupportActionBar();
        if (actionBar != null) {
            actionBar.setDisplayHomeAsUpEnabled(true);
            actionBar.setDisplayShowHomeEnabled(true);

        }
        Intent intent = getIntent();
        if (intent == null) {
            closeOnError();
        }
        movie = intent.getParcelableExtra("movie");
        id = String.valueOf(movie.getMovieId());
        review_recycler = findViewById(R.id.review_list);
        recyclerView = findViewById(R.id.trailer_rec);
        reviewModels = new ArrayList<>();
        model_list = new ArrayList<>();
        review_recycler.setLayoutManager(new LinearLayoutManager(this));
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        mDb = AppDatabase.getInstance(getApplicationContext());
        setData(findUrl, id, api_key);
        setReview(findUrl, id, api_key);

        desc = findViewById(R.id.detail_desc);
        desc.setText(movie.getOverview());
        title = findViewById(R.id.detail_name);
        title.setText(movie.getOriginalTitle());
        rate = findViewById(R.id.detail_rating);
        rate.setText(movie.getVoterAverage() + "/" + 10);
        release = findViewById(R.id.detail_release);
        release.setText(movie.getReleaseDate());
        favoriteBtn = findViewById(R.id.favourite);
        posture = findViewById(R.id.detail_poster);
        Picasso.get().load(movie.getPosterPath()).into(posture);

        favoriteBtn.setTextOn("SuccessFully Added");
        favoriteBtn.setTextOff("Add to Favorite");

        setUpFavoriteMovieButton ();

        favoriteBtn.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if (isChecked) {
                    favoriteBtn.getTextOn();
                    DetailsActivity.this.onFavoriteButtonClicked();
                } else {
                    favoriteBtn.setTextColor(Color.parseColor("#000000"));
                    favoriteBtn.getTextOff();
                    AppExecutors.getInstance().diskIO().execute(new Runnable() {
                        @Override
                        public void run() {
                            DetailsActivity.this.runOnUiThread(new Runnable() {
                                @Override
                                public void run() {
                                    mDb.movieDao().deleteMovie(Integer.parseInt(id));
                                }
                            });
                        }
                    });
                }
            }

        });
    }

    private void closeOnError() {
        finish();
        Toast.makeText(this, "Something went wrong.", Toast.LENGTH_SHORT).show();
    }

    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();
        if (id == android.R.id.home) {
            NavUtils.navigateUpFromSameTask(this);
            return true;
        }
        return super.onOptionsItemSelected(item);
    }

    @Override
    protected void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);
    }

    protected void onRestoreInstanceState(Bundle savedState) {
        super.onRestoreInstanceState(savedState);
    }

    public void onFavoriteButtonClicked() {
        final MyDataList movie = getIntent().getExtras().getParcelable("movie");
        AppExecutors.getInstance().diskIO().execute(new Runnable() {
            @Override
            public void run() {
                mDb.movieDao().insertMovie(movie);
            }
        });
    }

    private void setData(String findUrl, String id, final String api_key) {
        final String complete_url = findUrl + id + "/videos?api_key=" + api_key + "&language=en-US";

        class Task extends AsyncTask<Void, Void, Void> {

            @Override
            protected Void doInBackground(Void... voids) {
                JsonObjectRequest request = new JsonObjectRequest(Request.Method.GET, complete_url, null, new Response.Listener<JSONObject>() {
                    @Override
                    public void onResponse(JSONObject response) {
                        System.out.println(response);
                        try {
                            JSONArray array = response.getJSONArray("results");
                            System.out.println(array.toString() + "//" + array.length());
                            for (int i = 0; i < array.length(); i++) {
                                String name = array.getJSONObject(i).getString("name");
                                String key = array.getJSONObject(i).getString("key");
                                model_list.add(new trailerModel(key, name));

                            }
                            adapter = new trailerAdapter(model_list, DetailsActivity.this);
                            recyclerView.setAdapter(adapter);
                            adapter.notifyDataSetChanged();
                        } catch (Exception e) {

                        }
                    }
                }, new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {

                    }
                });
                RequestQueue requestQueue = Volley.newRequestQueue(getApplicationContext());
                requestQueue.add(request);
                return null;
            }
        }
        Task task = new Task();
        task.execute();

    }

    private void setReview(String findUrl, String id, String api_key) {
        final String complete_url = findUrl + id + "/reviews?api_key=" + api_key + "&language=en-US";

        class Task extends AsyncTask<Void, Void, Void> {

            @Override
            protected Void doInBackground(Void... voids) {
                JsonObjectRequest request = new JsonObjectRequest(Request.Method.GET, complete_url, null, new Response.Listener<JSONObject>() {
                    @Override
                    public void onResponse(JSONObject response) {
                        System.out.println(response);
                        try {
                            JSONArray array = response.getJSONArray("results");
                            System.out.println(array.toString() + "//" + array.length());
                            for (int i = 0; i < array.length(); i++) {
                                String name = array.getJSONObject(i).getString("author");
                                String key = array.getJSONObject(i).getString("content");
                                String url = array.getJSONObject(i).getString("url");
                                reviewModels.add(new reviewModel(name, key, url));
                            }
                            re_adapter = new reviewAdapter(reviewModels, DetailsActivity.this);
                            review_recycler.setAdapter(re_adapter);
                            re_adapter.notifyDataSetChanged();
                        } catch (Exception e) {

                        }
                    }
                }, new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {

                    }
                });
                RequestQueue requestQueue = Volley.newRequestQueue(getApplicationContext());
                requestQueue.add(request);
                return null;
            }
        }
        Task task = new Task();
        task.execute();
    }

    private void setUpFavoriteMovieButton() {
        DetailsMovieViewFactory factory =
                new DetailsMovieViewFactory(mDb, movie.getMovieId());
        final MovieDetailsViewModel viewModel =
                ViewModelProviders.of(this, factory).get(MovieDetailsViewModel.class);

        viewModel.getMovie().observe(this, new Observer<MyDataList>() {
            @Override
            public void onChanged(@Nullable MyDataList movieInDb) {
                viewModel.getMovie().removeObserver(this);

                if (movieInDb == null) {
                    favoriteBtn.setTextColor(Color.parseColor("#000000"));
                    favoriteBtn.setChecked(false);
                    favoriteBtn.getTextOff();
                } else if ((movie.getMovieId()== movieInDb.getMovieId()
                        && !favoriteBtn.isChecked())) {
                    favoriteBtn.setChecked(true);
                    favoriteBtn.setText("SuccessFully Added");
                    favoriteBtn.setTextColor(Color.parseColor("#b5001e"));
                } else {
                    favoriteBtn.setTextColor(Color.parseColor("#000000"));
                    favoriteBtn.setChecked(false);
                    favoriteBtn.getTextOff();
                }
            }
        });

    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
    }
}


