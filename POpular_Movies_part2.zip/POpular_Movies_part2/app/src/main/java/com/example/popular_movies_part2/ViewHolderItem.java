package com.example.popular_movies_part2;

import android.view.View;
import android.widget.ImageView;

public class ViewHolderItem {
    ImageView posterImage;
    ViewHolderItem(View view)
    {
        posterImage=view.findViewById(R.id.grid_image);
    }
}
