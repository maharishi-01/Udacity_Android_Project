package com.example.popular_movies_part2;

import androidx.lifecycle.LiveData;
import androidx.room.*;
import androidx.room.Insert;
import androidx.room.OnConflictStrategy;
import androidx.room.Query;

@Dao
public interface MovieDao {
    @Query("SELECT * FROM Movies")
    LiveData<MyDataList[]> loadAllMovies();
    @Insert(onConflict = OnConflictStrategy.IGNORE)
    void insertMovie(MyDataList movie);

    @Query("DELETE FROM Movies WHERE movieId = :movieId")
    void deleteMovie(int movieId);

    @Query("SELECT * FROM Movies WHERE movieId = :movieId")
    LiveData<MyDataList> loadMovieById(int movieId);
}
