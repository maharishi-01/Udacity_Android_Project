package com.example.popular_movies_part2.Adapter;

import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.example.popular_movies_part2.R;
import com.example.popular_movies_part2.trailerModel;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class trailerAdapter extends RecyclerView.Adapter<trailerAdapter.Holder> {
    List<trailerModel> list;
    Context context;

    public trailerAdapter(List<trailerModel> list, Context context) {
        this.list = list;
        this.context = context;
    }

    @NonNull
    @Override
    public trailerAdapter.Holder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.dummy_play, parent, false);
        return new Holder(v);
    }

    @Override
    public void onBindViewHolder(@NonNull trailerAdapter.Holder holder, int position) {
        String uri = list.get(position).getUrl();
        String name = list.get(position).getName();
        holder.setData(uri,name,position);
    }

    @Override
    public int getItemCount() {
        return list.size();
    }

    public class Holder extends RecyclerView.ViewHolder {
        TextView Name;
        ImageView play,share;

        public Holder(@NonNull View itemView) {
            super(itemView);
            Name = itemView.findViewById(R.id.play_name);
            play = itemView.findViewById(R.id.play);
            share=itemView.findViewById(R.id.share);
        }

        public void setData(String uri, String name, int position) {
            Name.setText(name);
            final String complete_url="https://www.youtube.com/watch?v="+uri;

            if (position>0)
            {
                share.setVisibility(View.GONE);
            }
            share.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Intent sendIntent = new Intent();
                    sendIntent.setAction(Intent.ACTION_SEND);
                    sendIntent.putExtra(Intent.EXTRA_TEXT, complete_url);
                    sendIntent.setType("text/plain");
                    Intent shareIntent = Intent.createChooser(sendIntent, null);
                    itemView.getContext().startActivity(shareIntent);
                }
            });
            play.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Intent intent = new Intent();
                    intent.setAction(Intent.ACTION_VIEW);
                    intent.addCategory(Intent.CATEGORY_BROWSABLE);
                    intent.setData(Uri.parse(complete_url));
                    itemView.getContext().startActivity(intent);
                }
            });
        }
    }
}
