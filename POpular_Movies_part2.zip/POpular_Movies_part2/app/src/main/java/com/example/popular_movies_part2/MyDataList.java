package com.example.popular_movies_part2;

import android.os.Parcel;
import android.os.Parcelable;

import androidx.room.Entity;
import androidx.room.Ignore;
import androidx.room.PrimaryKey;

@Entity(tableName = "Movies")
public class MyDataList implements Parcelable {

    @PrimaryKey(autoGenerate = true)
    private int dbMovieId;
    private int movieId;
    private String originalTitle;
    private String posterPath;
    private String overview;
    private String releaseDate;
    private String voterAverage;

    @Ignore
    private boolean isFavoriteMovie = false;
    MyDataList()
    {

    }


    public int getDbMovieId() {
        return dbMovieId;
    }

    public void setDbMovieId(int dbMovieId) {
        this.dbMovieId = dbMovieId;
    }

    public int getMovieId() {
        return movieId;
    }

    public void setMovieId(int movieId) {
        this.movieId = movieId;
    }

    public String getOriginalTitle() {
        return originalTitle;
    }

    public void setOriginalTitle(String originalTitle) {
        this.originalTitle = originalTitle;
    }

    public String getPosterPath() {
        return posterPath;
    }

    public void setPosterPath(String posterPath) {
        this.posterPath = posterPath;
    }

    public String getOverview() {
        return overview;
    }

    public void setOverview(String overview) {
        this.overview = overview;
    }

    public String getReleaseDate() {
        return releaseDate;
    }

    public void setReleaseDate(String releaseDate) {
        this.releaseDate = releaseDate;
    }

    public String getVoterAverage() {
        return voterAverage;
    }

    public void setVoterAverage(String voterAverage) {
        this.voterAverage = voterAverage;
    }

   @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeString(originalTitle);
        dest.writeString(posterPath);
        dest.writeString(overview);
        dest.writeString(releaseDate);
        dest.writeString(voterAverage);
        dest.writeInt (movieId);

    }

    private MyDataList(Parcel parcel) {
        originalTitle = parcel.readString();
        posterPath = parcel.readString();
        overview = parcel.readString();
        releaseDate = parcel.readString();
        voterAverage = parcel.readString();
        movieId = parcel.readInt ();

    }
    public static final Parcelable.Creator<MyDataList> CREATOR = new Parcelable.Creator<MyDataList>() {
        public MyDataList createFromParcel(Parcel src) {
            return new MyDataList(src);
        }

        public MyDataList[] newArray(int size) {
            return new MyDataList[size];
        }
    };
}

