package com.ajdi.yassin.javajokerlib;

public class Joker {

    public String tellAJoke() {
        return "Q. Why was 6 afraid of 7?\n" +
                "\n" +
                "A.Because 7, 8, 9.\n" +
                "\n";
    }
}
