package com.udacity.gradle.builditbigger;

public interface JokeListener {

    void onJokeLoaded(String joke);
}
