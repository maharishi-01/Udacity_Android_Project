package com.udacity.gradle.builditbigger.backend;

/**
 * @author Yassin Ajdi
 * @since 3/7/2019.
 */
public class Joke {
    private String text;

    public String getText() {
        return text;
    }

    public void setText(String text) {
        this.text = text;
    }
}
