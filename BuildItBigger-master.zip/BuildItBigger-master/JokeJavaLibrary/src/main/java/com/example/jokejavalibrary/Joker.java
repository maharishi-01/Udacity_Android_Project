package com.example.jokejavalibrary;

public class Joker {

    // TO DO: have a list of jokes in an ArrayList
    // and return a random one, but you can improve that later
    public static String getJoke() {
        return "This is a joke";
    }

}
